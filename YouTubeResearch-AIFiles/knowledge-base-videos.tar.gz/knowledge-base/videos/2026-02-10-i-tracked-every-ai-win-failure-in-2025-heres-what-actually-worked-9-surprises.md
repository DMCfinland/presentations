---
title: I Tracked Every AI Win & Failure in 2025. Here's What Actually Worked (9 Surprises)
type: video-analysis
channel: ai-news-strategy-daily-nate-b-jones
video_id: uVZMc-i5EEs
video_url: https://www.youtube.com/watch?v=uVZMc-i5EEs
duration: 13:52
published: 2025
analyzed: 2026-02-10
tags: [ai-strategy, workflow-design, code-as-tool, image-generation, verification-loops]
key_concepts: [llm-code-integration, messy-middle, quality-over-cost, creative-problem-solving, agentic-workflows]
strategic_patterns: [infrastructure-as-enabler, middle-layer-value-capture, scope-vs-automation]
quality_score: 5
strategic_value: high
---

# I Tracked Every AI Win & Failure in 2025. Here's What Actually Worked (9 Surprises)

## Summary

2025's AI revolution succeeded not through sci-fi breakthroughs but through practical infrastructure unlocks: LLMs using code as a tool, image generation enabling graphical UI innovation, and verification loops powering reliable agentic systems. The surprising winners were non-technical creative problem solvers who designed effective workflows, and the "messy middle" layer proved far more defensible than anticipated. The shift from cost-cutting to quality enhancement signals AI's maturation from magic button to sophisticated tool requiring proper scoping and human expertise.

---

## 1. Context

**Background:** This is a retrospective analysis of 2025's AI developments, evaluating what actually delivered value versus what generated hype. The creator tracked wins and failures across the year to identify patterns that matter for practical AI implementation in 2026 and beyond.

**Why This Matters:** As organizations move past initial AI vendor purchases and "magic button" thinking, understanding what actually worked in 2025 provides critical guidance for strategic AI investments. The gap between hype and reality has narrowed enough to identify durable patterns versus transient trends.

**Key Stats:** 
- The transition happened "partway through the year" when verification loops became mainstream
- Multiple paradigm shifts occurred: Cloud Code, Model Context Protocol, Skills, Codeex, Cursor
- Market selection for creative problem solvers happened "quicker than anticipated"

---

## 2. Vision & Why

**Core Mission:** To clarify where actual value is coming from in the AI revolution and make visible the gaps that still exist, moving beyond science fiction promises to practical implementation patterns.

**The "Why" Behind It:** Organizations and individuals need to distinguish between sustainable AI capabilities and overhyped features to allocate resources effectively. The gap between "magic button" expectations and workflow design reality creates significant competitive advantage for those who understand the difference.

**Enduring Nature:** 
- **Timeless:** Code as interface to computation, verification as quality assurance, human creativity in problem definition, the messy middle's value in transformation
- **Time-bound:** Specific tools (Cursor, Cloud Code), current limitations of agents, 2025's image generation breakthroughs, today's cost structure

---

## 3. Strategic Engine

**How This Actually Works:** AI value creation in 2025 operated through three primary mechanisms:
1. **Infrastructure enablement** - LLMs gained ability to manipulate computers through code
2. **Interface evolution** - Images became reliable enough to enable new user experiences
3. **Workflow composition** - Verification loops + proper scoping + iteration created reliable systems

**Key Components:**
1. **Code as Tool Layer** - LLMs executing code to interact with any computer system
2. **Image Generation Quality** - Reliable text-in-image, infographics, layouts, slides
3. **Verification Infrastructure** - Hard-to-game loops enabling agentic iteration
4. **The Messy Middle** - Transformation layers between raw AI outputs and domain value
5. **Creative Workflow Design** - Human-designed systems leveraging AI as components

**Why This Works:** Each component unlocks a different constraint:
- Code access removes the interface bottleneck (LLMs can touch any system)
- Image quality enables human-speed information processing
- Verification loops provide the "jet engine" for agent performance
- The messy middle captures domain-specific transformation value
- Creative design ensures AI serves actual user needs vs. theoretical capabilities

---

## 4. Behavioral Design

**Behavioral Principles:**
- **Proper scoping over limitless automation** - Bounded, well-defined workflows outperform autonomous agents
- **Iteration velocity over perfection** - Fast feedback loops with validators, retries, templates beat slow custom engineering
- **Quality enhancement over cost cutting** - Leveling up customer experience creates more durable value than headcount reduction
- **Domain expertise + technical curiosity** - The "technical/non-technical" divide dissolves into willingness to learn AI skills for your domain

**Incentive Structure:**
- Rewards: Fast iteration, low-tech pragmatism (templates, validators), workflow thinking
- Punishes: "Worshipping at the altar of a particular model," confusing agentic with good, waiting for perfect AI developers
- Encourages: Picking up technical skills to solve domain problems, treating engineering as designable workflow

**Alignment Mechanisms:**
- Verification loops keep agents honest and on-track
- Scheduled tasks maintain consistent engagement
- Domain-specific middle layers ensure outputs match user needs
- Quality metrics (vs. just cost metrics) align AI deployment with customer value

---

## 5. Time & Attention

**Where Time Flows:**
- **System design time** over coding time - "individuals outexecute entire development teams because they treated engineering as a workflow they could design"
- **Iteration cycles** over planning perfection - aggressive, rapid iteration with verification
- **Proper scoping** over unlimited autonomy - defining bounded, valuable workflows
- **Learning domain-relevant AI skills** over waiting for AI specialists

**What This System DOESN'T Spend On:**
- Custom AI development when templates/validators work
- Perfect agentic systems when scoped workflows deliver
- Pure cost-cutting when quality enhancement drives more value
- Worrying about hyperscaler competition in the middle layer
- Reinventing the wheel where habits/consistency have value

**Allocation Philosophy:** 
"Everyone picks up the degree of technical skills they need to solve the problems they're interested in." Time investment follows problem interest, not credential requirements. AI democratizes technical capability, so attention flows to creative problem definition rather than implementation mechanics.

---

## 6. Moats & Time Horizon

**Competitive Advantages:**

1. **Workflow Design Capability** - Hard to replicate because it requires domain expertise + systems thinking + rapid iteration culture
2. **Messy Middle Infrastructure** - "So much value in transforming messy inputs into structured representations, in routing intent, in orchestrating calls, in handling exceptions" creates defensible position despite hyperscaler competition
3. **Verification Loop Libraries** - First movers building standard evaluation frameworks (accessibility, quality checks) create network effects
4. **Creative Problem-Solving Culture** - Organizations that selected for "very strong creative problem solving instincts" compound advantage as AI makes technical skills more accessible
5. **Quality-First Positioning** - Companies focusing on customer experience enhancement vs. cost cutting build stronger customer relationships and pricing power

**Time Horizon:**
- **Short-term (2025-2026):** Infrastructure unlocks create immediate productivity gains for early adopters; competitive advantage from faster iteration
- **Medium-term (2026-2028):** Messy middle layer consolidates around winners; verification loop standards emerge; quality-focused firms differentiate
- **Long-term (2028+):** Creative problem-solving culture + domain expertise becomes primary moat as AI technical capabilities commoditize

**Why Time Is Your Friend:** 
- Workflow design skills compound with practice
- Verification loop libraries grow more comprehensive
- Quality enhancement builds customer loyalty and pricing power
- Creative culture attracts talent as technical barriers lower
- Domain expertise + AI fluency becomes rarer as AI capabilities democratize

---

## 7. Flywheels & Lock-In

**Primary Flywheel: The Creative Workflow Design Loop**

**Flywheel Visualization:**
[Domain Problem Recognition] → [Low-tech workflow design with templates/validators/retries] → [Rapid iteration with verification loops] → [Quality outputs that exceed human-only capability] → [Deeper domain insights from scaled execution] → [More sophisticated problem recognition] → [Back to workflow design, with better understanding]

**Secondary Flywheel: The Messy Middle Value Capture**

[Raw AI model outputs] → [Domain-specific transformation layer] → [Valuable user experience] → [User feedback and usage data] → [Refined transformation logic] → [Better raw input handling] → [More valuable outputs with same AI substrate]

**Lock-In Mechanisms:**

1. **Skill Accumulation** - "Those folks are understanding the new principles for evolving agentic systems. And then they become more and more valuable"
2. **Workflow Libraries** - Templates, validators, and verification loops accumulate and compound
3. **Quality Reputation** - Once positioned as quality leader vs. cost cutter, customer expectations lock in pricing power
4. **Integration Depth** - Messy middle infrastructure that handles exceptions, routes intent, orchestrates calls becomes increasingly embedded
5. **Cultural Selection** - Organizations that selected for creative problem solvers create self-reinforcing hiring and retention patterns

**Compounding Effect:**
Each iteration through the workflow design loop generates:
- Better understanding of which problems to scope
- More sophisticated verification approaches
- Deeper domain insights from AI-scaled execution
- Stronger talent attracted to creative problem-solving culture
- More defensible middle-layer infrastructure

The system improves geometrically because each component enhances the others: better scoping enables better verification, which enables more ambitious workflows, which attracts better talent, which enables better scoping.

---

## 8. System Beneficiaries

**Winners:**

1. **Creative Problem Solvers** - "Technical people that wanted to express their creative side and creative people that never felt like they could be technical finally have a chance"
   - Benefit: Can now execute on ideas previously blocked by technical barriers
   - Mechanism: LLMs + code as tool democratize technical capability

2. **Workflow Designers Over Pure Developers** - "Individuals outexecute entire development teams because they treated engineering as a workflow they could design"
   - Benefit: Systems thinking + domain knowledge > pure coding skill
   - Mechanism: Templates, validators, retries, iteration velocity beat custom engineering

3. **Messy Middle Layer Builders** - Despite fears of hyperscaler competition
   - Benefit: "So much value in transforming messy inputs into structured representations"
   - Mechanism: Domain-specific transformation, routing, orchestration, exception handling

4. **Quality-Focused Organizations** - "More and more leaders want to have a conversation about quality"
   - Benefit: Differentiation through customer experience vs. commoditized cost-cutting
   - Mechanism: AI enables quality/volume impossible with human-only operations

5. **Domain Experts Willing to Learn AI** - "The question is going to be, are you curious about the problems that are relevant in your domain?"
   - Benefit: Can now solve previously intractable domain problems
   - Mechanism: Technical skills become increasingly approachable through AI

**Losers:**

1. **Pure AI Developers (Without Domain Expertise)** - "I actually think you need someone who can design systems"
   - Disadvantage: Narrow technical focus less valuable than systems thinking + domain knowledge
   - Why: Workflow design capability matters more than model expertise

2. **Magic Button Believers** - "Agents were oversold...because they were sold as magic buttons"
   - Disadvantage: Unrealistic expectations lead to disappointment and abandoned investments
   - Why: Proper scoping and workflow design required, not autonomous magic

3. **Cost-Cutting-Only Organizations** - Focus on headcount reduction vs. quality enhancement
   - Disadvantage: Commoditized positioning, talent flight, customer experience degradation
   - Why: "Still need their people to deliver the kind of value that only people can deliver"

4. **Slop Content Creators** - Low-quality, unconstrained AI content
   - Disadvantage: "AI slop is a symptom of unconstrained and unmanaged artificial intelligence"
   - Why: Selection pressure for quality + verification systems filter out slop

**Ethical Considerations:**

1. **Labor Market Disruption** - "Not a ton of evidence that AI is driving overall job market declines" but anecdotal impacts exist
2. **Quality vs. Volume Trade-offs** - Temptation to scale low-quality outputs
3. **Attention Economy** - "People's attention as a precious asset" vs. AI-generated content flood
4. **Accessibility** - Who gets access to quality AI workflows vs. slop-generating tools?
5. **Disclosure** - "If you announce that your ad is AI, there's generally a backlash" - when to disclose AI involvement?

---

## 9. System Health Metric

**What to Optimize For:** **Workflow Iteration Velocity to Quality Output Ratio**

This compound metric measures: (Number of workflow iterations per week) × (Quality score of final outputs) / (Resources invested)

**Why This Metric:**

1. **Captures Core Value Creation** - Combines the speed advantage (iteration velocity) with the quality advantage (better outputs) that define successful 2025 AI implementations
2. **Prevents Gaming** - Can't optimize iteration speed alone (leads to slop) or quality alone (leads to over-engineering)
3. **Reflects Strategic Insights** - Embodies "individuals outexecute entire development teams" through fast iteration AND "quality lift over cost cutting" through output quality
4. **Indicates System Health** - High ratio means verification loops working, scoping appropriate, creative problem-solving effective
5. **Predictive of Sustainability** - Organizations optimizing this ratio build compounding advantages vs. one-time gains

**How to Measure:**

**Iteration Velocity Component:**
- Count: Workflow design cycles per week (how many times you modify templates, validators, verification loops)
- Track: Time from problem identification → workflow design → iteration → verified output
- Target: 10+ iterations/week for active workflows (daily refinement cadence)

**Quality Output Component:**
- Measure: Pass rate on verification loops (what % of outputs meet hard-to-game quality standards)
- Score: Customer satisfaction delta (improvement in experience quality metrics)
- Assess: Information density / usefulness (vs. slop detection)

**Resource Investment Component:**
- Time: Person-hours invested in workflow design + monitoring
- Cost: AI API costs + infrastructure
- Attention: Team cognitive load and context-switching overhead

**Practical Implementation:**
```
Weekly Health Score = 
  (Workflow iterations × Verification pass rate × Customer quality delta) 
  / (Person-hours + Normalized AI costs)

Green Zone: Score > 2.0 (high velocity, high quality, efficient)
Yellow Zone: 0.5 - 2.0 (one dimension lagging)
Red Zone: < 0.5 (low velocity, low quality, or inefficient)
```

**Leading Indicators:**
- Increasing iteration velocity without quality degradation
- Verification loops catching problems before human review
- Team requesting more workflow design time vs. more AI budget
- Customer feedback referencing specific quality improvements

---

## 10. Unique Insights & Quotes

### Memorable Quotes

> "2025 didn't deliver the science fiction version of AI that gets lots of clicks, but it exceeded my expectation in ways that matter more. It clarified where value is actually coming from in the AI revolution, and it made the gaps that we still have visible in a way that I think is useful."

> "I think that we all or almost all of us underestimated how powerful it is when you allow an LLM to use code as a tool. That turns out to be an absolutely massive unlock."

> "Now plain English allows you to talk with your computer. Now plain English allows you to manipulate the files on your computer any way you want. Absolutely massive unlock."

> "I have watched individuals outexecute entire development teams because they treated engineering as a workflow they could design and they didn't worship at the altar of a particular model."

> "I think we are going to have to throw away the idea that there are technical and non-technical people. I think a more accurate description is that everyone picks up the degree of technical skills they need to solve the problems they're interested in."

> "It's like hooking up a jet engine to an airplane. Like it's amazing how fast you can go when you stick an agent against a verification loop that is hard to game and you say go get it done."

> "The messy middle turned out to be the entire game. Everyone wants to talk about the idea of the front end and there was a lot of talk during the middle of the year about super model makers or hyperscalers owning the entire stack...It turns out that there is so much value in transforming messy inputs into structured representations, in routing intent, in orchestrating calls, in handling exceptions, in providing useful user interfaces for specific things."

> "Agents were oversold. That was something that a lot of people were disappointed by because they were sold as magic buttons. But the flip side is when you put an agent in a good workflow, that's a really pleasant surprise."

> "AI slop is a symptom of unconstrained and unmanaged artificial intelligence. And that companies that start to get into marketing, start to get into producing content at scale for AI, if you build the right systems, you can produce really compelling, very performant ad flows, very performant email marketing, very performant content marketing that outperforms what humans can do."

> "The firms that win are firms that regard their people and their people's attention as a precious asset. And they're designing AI systems around them in ways that allow people to put their expertise to work where it matters most."

### Non-Obvious Insights

- **Code-as-tool was underestimated infrastructure:** The unlock wasn't better AI models but giving LLMs code execution capability, which turned them from text generators into computer manipulators. This was "visible as a vision" early in 2025 but its magnitude wasn't appreciated until deployment.

- **Images solved the graphical interface problem:** The breakthrough wasn't just "pretty pictures" but reliable text-in-image, infographics, and layouts that enable "graphical user interfaces that evolve with you" - potentially as wearables, generative UIs, or context-adaptive screens.

- **Individual workflow designers beat development teams:** The competitive advantage shifted from technical depth to systems thinking + iteration velocity. Single people with good workflow design intuition outperformed teams focused on custom AI engineering.

- **The messy middle is underbuilt, not vulnerable:** Despite fears that hyperscalers would own the full stack, domain-specific transformation layers (routing, orchestration, exception handling, UI) proved far more defensible than anticipated.

- **Verification loops are the "jet engine" for agents:** The unlock wasn't better autonomous AI but rather AI + hard-to-game quality loops + iteration permission. This combination enables geometric performance improvements.

- **Technical/non-technical is obsolete categorization:** The real divide is curiosity about domain problems + willingness to learn AI skills, not credentials. "Everyone picks up the degree of technical skills they need to solve the problems they're interested in."

- **Quality lift replaced cost cutting as primary value:** After initial vendor purchases failed to deliver magic buttons, sophisticated buyers shifted to "how can we level up the quality of the experience we provide to customers in ways that were unimaginable because of AI?"

- **AI slop is solvable, not inevitable:** With proper systems (verification, grounding, fact-checking, structure), AI can produce "really compelling, very performant" content that outperforms humans - slop results from lack of constraint, not AI limitations.

- **Creative problem-solving became the scarce skill:** As technical capabilities democratized through AI, "very strong creative problem solving instincts" became the market selection criterion faster than anticipated.

- **Proper scoping beats autonomous agency:** "When you put an agent in a good workflow" yields tremendous reliable value, while unlimited autonomous agents overpromise and underdeliver - the design skill is knowing what to scope.

---

## 11. Application & Mental Model

### When to Use This Pattern

**Signal Indicators:**
- Your organization has completed initial AI vendor purchases and is asking "what now?"
- Team members express disappointment that AI isn't a "magic button"
- You're choosing between hiring more AI developers vs. training domain experts
- Cost-cutting AI initiatives aren't delivering expected customer experience value
- Competition is commoditizing your current AI capabilities
- You're deciding whether to build middle-layer infrastructure vs. rely on hyperscalers
- Creative problem solvers are underutilized because they're "not technical"

**Applicable Conditions:**
- **Workflow-intensive operations** where iteration velocity compounds value
- **Quality-differentiated markets** where customer experience > cost leadership
- **Domain-specific problems** where transformation logic is non-obvious
- **High-verification environments** where output quality is measurable
- **Talent-constrained contexts** where creative problem-solvers > pure developers

### When NOT to Use This Pattern

**Anti-patterns:**
- **Pure commodity plays** where cost is only differentiator (may favor brutal cost-cutting over quality)
- **Fully autonomous requirement** where human-in-loop workflow design is impossible
- **Zero iteration tolerance** where one-shot perfection is required
- **Completely novel problems** where verification loops can't be designed yet
- **Pure research contexts** where workflow optimization premature

**Conditions that make it inappropriate:**
- Regulatory environments prohibiting AI in decision-making
- Situations where "how we got here" matters more than output quality
- Contexts where iteration creates unacceptable risks (high-stakes one-time decisions)
- Organizations culturally opposed to creative problem-solving vs. credentialism

### How to Apply to 1658 Holdings Companies

**Finland DMC Oy:**

1. **Customer Experience Workflow Design**
   - *Application:* Design itinerary creation as workflow with verification loops (customer preference matching, timing validation, accessibility checks)
   - *Expected Outcome:* Individual workflow designers create better custom itineraries faster than teams of travel agents
   - *Key Move:* Train current domain experts (who know Finnish tourism) in workflow design vs. hiring AI developers

2. **Messy Middle for Tour Orchestration**
   - *Application:* Build transformation layer between raw supplier data (hotels, activities, transport) and customer-ready itineraries
   - *Expected Outcome:* Defensible infrastructure layer that hyperscalers can't easily replicate (requires Finnish tourism domain knowledge)
   - *Key Move:* Invest in routing logic, exception handling, and supplier integration vs. pure AI model costs

3. **Image Generation for Destination Marketing**
   - *Application:* Leverage 2025's image quality unlock for personalized destination visualizations, custom maps, itinerary layouts
   - *Expected Outcome:* Quality lift in customer decision-making and satisfaction (vs. generic photos)
   - *Key Move:* Build verification loops for image quality (accuracy, branding, accessibility) vs. unconstrained generation

4. **Quality Over Volume Positioning**
   - *Application:* Position AI as enabling "luxury personalization at scale" vs. cost-cutting mass tourism
   - *Expected Outcome:* Premium pricing power, customer loyalty, talent attraction
   - *Key Move:* Measure customer experience quality delta vs. cost per booking

**General Principles:**

1. **Invest in Workflow Design Capability Before AI Developers**
   - Identify creative problem-solvers in each company
   - Train them in low-tech AI workflow patterns (templates, validators, retries)
   - Measure iteration velocity + quality output ratio
   - Promote based on systems thinking vs. pure technical credentials

2. **Build Defensible Messy Middle Layers**
   - Map domain-specific transformation needs (what turns raw AI → customer value?)
   - Invest in routing logic, orchestration, exception handling, useful UIs
   - Don't fear hyperscaler competition - domain specificity is the moat
   - Accumulate verification loops as reusable infrastructure

3. **Shift from Cost-Cutting to Quality Enhancement**
   - Frame AI investments as "quality lift" not headcount reduction
   - Measure customer experience improvements, not just efficiency
   - Regard "people's attention as precious asset" - use AI to elevate their work
   - Build pricing power through differentiation vs. commodity competition

4. **Prioritize Verification Infrastructure**
   - Define hard-to-game quality loops for each workflow
   - Build libraries of standard verifications (accessibility, accuracy, brand alignment)
   - Create "jet engine" effect by pairing agents with tight feedback loops
   - Share verification patterns across portfolio companies

5. **Democratize Technical Skills Across Domain Experts**
   - Abandon technical/non-technical divide
   - Support domain experts learning AI skills relevant to their problems
   - Measure curiosity and problem interest vs. credentials
   - Create scheduled learning systems (like daily code reviews example)

---

## Strategic Patterns Identified

1. **Infrastructure-as-Enabler Pattern:** The most valuable AI advances in 2025 weren't better models but infrastructure unlocks (code-as-tool, reliable images, verification loops) that removed constraints. Strategic implication: Invest in removing bottlenecks for existing AI capabilities before betting on future model improvements.

2. **Middle-Layer Value Capture Pattern:** Despite fears of disintermediation, the "messy middle" (transformation, routing, orchestration, exceptions, domain-specific UI) proved highly defensible and underbuilt. Strategic implication: Domain-specific transformation layers create durable moats even with commoditized AI substrates.

3. **Scope-vs-Automation Pattern:** Properly scoped workflows with AI components outperformed autonomous AI agents trying to do everything. Strategic implication: The design skill is knowing what to automate fully vs. what to keep in human-AI loop vs. what to keep human-only.

---

## Quality Assessment

**Transcript Quality:** excellent
- Complete sentences, clear speaker attribution
- Technical concepts explained with examples
- Temporal markers present (beginning of year, partway through, etc.)
- Minimal transcription errors or unclear passages

**Analysis Confidence:** high
- Consistent strategic framework throughout video
- Multiple concrete examples supporting each insight
- Clear practitioner perspective (not just theory)
- Temporal consistency (reflecting on 2025 from early 2026 vantage)

**Strategic Value:** high
- Directly actionable for AI strategy decisions
- Distinguishes hype from durable patterns
- Provides specific failure modes to avoid
- Applicable across multiple industries and company sizes

**Completeness:** complete
- All 11 dimensions fully addressed
- 10 exact quotes captured
- 10+ non-obvious insights identified
- Specific portfolio company applications provided
- Quality assessment included