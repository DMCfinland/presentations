---
title: I Summarized the 313 Slide State of AI Report so You Don't Have to Read It—Here's the TLDR
type: video-analysis
channel: ai-news-strategy-daily-nate-b-jones
video_id: gRhOo6uT-fM
video_url: https://www.youtube.com/watch?v=gRhOo6uT-fM
duration: 28:29
published: 2025
analyzed: 2026-02-10
tags: [ai-infrastructure, cost-optimization, routing-intelligence, sovereign-ai, capability-curves]
key_concepts: [capability-to-cost-curve, model-routing, infrastructure-constraints, answer-engine-optimization, intelligent-routing]
strategic_patterns: [exponential-cost-deflation, distribution-shift, infrastructure-as-moat]
quality_score: 5
strategic_value: high
---

# I Summarized the 313 Slide State of AI Report so You Don't Have to Read It—Here's the TLDR

## Summary

The State of AI Report 2025 reveals a fundamental strategic shift: the "model IQ contest is over and the infrastructure wars are just beginning." The critical insight is that intelligence per dollar is improving exponentially (doubling every 3-8 months), 3-7x faster than Moore's Law, creating unprecedented opportunities for routing-intelligent systems while simultaneously exposing hard infrastructure constraints (power, water, permits) that will determine winners. This creates a paradox: AI capability is accelerating faster than most strategic plans assume, yet physical infrastructure constraints will create bottlenecks that make routing intelligence—not frontier model access—the primary competitive advantage for the next 2-3 years.

---

## 1. Context

**Background:** 
The State of AI Report is an annual publication from Air Street Capital (led by Nathan Benaich) now in its eighth year. The 2025 edition analyzes 313 slides covering the current state of AI capabilities, economics, infrastructure, and competitive dynamics. This year's report marks a strategic inflection point: moving from a focus on pure model intelligence to systems-level optimization amid real-world constraints.

**Why This Matters:**
This represents a fundamental reframing of AI strategy for the next 18-24 months. Organizations still optimizing for "best model" selection will be outcompeted by those optimizing for intelligent routing, cost efficiency, and infrastructure access. For business leaders, this means:
- Current strategic assumptions about AI capability growth may be too conservative (doubling every 4-5 months vs. 18-24 months)
- Infrastructure constraints (power, permits, water) are no longer theoretical—they're already limiting model availability
- Distribution has shifted dramatically to answer engines (ChatGPT has 60% AI search share, 800M weekly active users)
- "Sovereign AI" investments are often infrastructure plays disguised as independence strategies

**Key Stats:**
- Intelligence per dollar doubles every 3-8 months (vs. Moore's Law at 18-24 months)
- Google: 3.4-month doubling time (fastest)
- OpenAI: 5.8-month doubling time
- GPT-4o: 12x cheaper than Claude, 24x cheaper than GPT-4 Turbo for 400K token context windows
- ChatGPT: 800M weekly active users, ~60% AI search market share
- Perplexity: 780M queries in May 2025, growing 20% month-over-month
- AI referral conversion rates: 11% (competitive with paid search, far exceeding organic search)
- Processing volume: ~1 quadrillion tokens/month across API providers
- US power shortfall by 2028: 68 gigawatts
- Single gigawatt data center: $50B capex, $11B/year to operate
- NIMBY opposition: $64B in blocked US data center projects
- 100MW data center: 2 million liters/day water consumption

---

## 2. Vision & Why

**Core Mission:**
Enable organizations to extract maximum economic value from AI by understanding that competitive advantage has shifted from "accessing the smartest model" to "routing computational work to the cheapest capable model" while navigating real infrastructure constraints.

**The "Why" Behind It:**
The fundamental economics of AI have changed. When capability per dollar doubles every 4-5 months, three strategic forces compound:
1. **Capability-to-cost curve**: You can obtain frontier-adjacent performance for 1/20th the price of 6 months ago
2. **Distribution question**: Answer engines (not traditional search) are capturing intent and conversion
3. **Physical infrastructure question**: Atoms (power, water, permits) constrain bits (tokens, intelligence)

This creates a window where routing intelligence, distribution capture, and infrastructure access become more valuable than frontier model IQ.

**Enduring Nature:**

*Timeless Principles (will matter in 2030+):*
- Economic value flows to systems that optimize cost-per-capability, not just capability
- Distribution compounds faster than technology in mature markets
- Physical infrastructure constraints eventually limit digital scalability
- Intelligence becomes a commodity when cost approaches zero; routing becomes the skill

*Time-Bound Specifics (2024-2026):*
- Specific doubling times (3-8 months) will slow as models approach certain capability ceilings
- Current frontier model makers (OpenAI, Anthropic, Google) may shift competitive positions
- NIMBY opposition and permitting timelines are political/regulatory, not fundamental
- Specific cost ratios (12x, 24x) will compress as competition intensifies

---

## 3. Strategic Engine

**How This Actually Works:**

The strategic engine operates through three compounding loops:

1. **Cost-Capability Deflation Loop**: As models improve and inference becomes cheaper, the same intelligence becomes accessible at exponentially lower prices → This enables higher-volume usage → Higher volume creates more training data and optimization pressure → Models improve faster at lower cost points

2. **Distribution Capture Loop**: Answer engines provide superior conversion (11% vs. organic search) → This attracts more users and queries → More queries provide better training data for routing and synthesis → Better synthesis increases conversion → Stronger distribution position

3. **Infrastructure Concentration Loop**: Organizations with power/permits can build capacity → Capacity enables model training and serving → Better models attract more API customers → API revenue funds more infrastructure investment → Infrastructure access becomes a competitive moat

**Key Components:**

1. **Routing Intelligence**: Systems that dynamically select the right model (speed-optimized vs. capability-optimized) based on task detection, optimizing cost/latency/quality trade-offs

2. **Multi-Model Architecture**: Ability to route across multiple model providers (OpenAI, Anthropic, Google, open-weights Chinese models) to avoid single-vendor lock-in and capacity constraints

3. **Infrastructure Access**: Secured capacity for power, cooling, networking, GPUs—the physical constraints that determine token availability

4. **Answer Engine Optimization (AEO)**: Structured data, canonical APIs, citation-friendly formatting that makes content parseable by AI synthesis systems

5. **Capability Measurement**: Moving beyond marketing benchmarks to real economic work measures (like OpenAI's GDP-val) that discount topline intelligence claims

**Why This Works:**

The logic is counter-intuitive but powerful: As intelligence becomes cheaper, the bottleneck shifts from "access to smart models" to "efficient orchestration of intelligence at scale." This works because:

- **Pareto Principle Applied to Intelligence**: 80% of tasks can be solved by cheaper models; routing enables you to reserve expensive frontier calls for the 20% that truly need it
- **Distribution Beats Technology**: In mature markets, whoever owns the intent/conversion layer captures more value than whoever builds the best underlying technology
- **Infrastructure Scarcity Creates Moats**: When demand scales faster than supply, those who secured infrastructure capacity early capture disproportionate value
- **Compounding Advantage**: Each of these advantages reinforces the others—better routing enables more volume, more volume funds infrastructure, infrastructure enables better models, better models attract distribution

---

## 4. Behavioral Design

**Behavioral Principles:**

1. **Intelligent Defaulting**: Systems should route users to optimal model choices invisibly, not burden them with selection
   - Example: GPT-4o's router UX dynamically selects speed-optimized vs. capability-optimized variants
   - Principle: Minimize cognitive load while maximizing outcome quality

2. **Structured Decision Architecture**: Design workflows that make it easy to use the right tool for the job
   - Principle: "Make the right thing the easy thing"
   - Anti-pattern: Defaulting to frontier models for all tasks because it's simpler

3. **Transparency in Constraints**: When infrastructure limits model availability, communicate this clearly rather than quietly degrading service
   - Example: Anthropic's honest communication about infrastructure constraints vs. silent degradation
   - Builds trust and enables users to adapt behavior

4. **Progressive Capability Disclosure**: Start users with simpler, faster models and escalate to frontier models only when demonstrated need exists
   - Prevents premature optimization and excessive costs
   - Trains users to develop appropriate model selection intuition

**Incentive Structure:**

*Encouraged Behaviors:*
- **Task Decomposition**: Breaking complex requests into smaller tasks that can be routed to cheaper models
- **Batch Processing**: Grouping similar tasks to optimize routing efficiency
- **Iterative Refinement**: Starting with fast/cheap models and escalating only when needed
- **AEO Investment**: Structuring content for AI parseability to capture answer engine distribution

*Discouraged Behaviors:*
- **Default-to-Frontier**: Automatically using the "best" model without considering cost/speed trade-offs
- **Single-Vendor Lock-in**: Depending exclusively on one model provider (concentrates both capability and infrastructure risk)
- **Ignoring Infrastructure Signals**: Building roadmaps that assume infinite API scalability
- **Topline Optimization**: Optimizing for benchmark scores rather than real economic work

**Alignment Mechanisms:**

1. **Economic Feedback Loops**: Direct cost visibility per query helps users internalize routing optimization
2. **Quality Gates**: Automatic escalation to stronger models when output quality falls below thresholds
3. **Latency Rewards**: Faster responses from cheaper models create positive reinforcement
4. **Capacity Signals**: Transparent communication about model availability helps users adapt strategies
5. **Conversion Metrics**: In answer engines, showing which content formats drive higher conversion reinforces AEO investment

---

## 5. Time & Attention

**Where Time Flows:**

*High-Value Time Investment:*
1. **Building Routing Intelligence** (30-40% of AI strategy time)
   - Developing task detection systems
   - Creating cost/quality trade-off frameworks
   - Building multi-model orchestration layers
   - Measuring real economic work, not benchmarks

2. **Infrastructure Relationships** (20-30% of strategic attention)
   - Understanding power/permit constraints
   - Diversifying infrastructure dependencies
   - Monitoring capacity availability signals
   - Planning for infrastructure bottlenecks

3. **Distribution Capture** (20-30%)
   - Answer Engine Optimization (AEO)
   - Structured data architecture
   - Citation-friendly formatting
   - API design for AI parseability

4. **Capability Evaluation** (10-20%)
   - Real-world task testing
   - Discount-rate calculation for topline claims
   - Measuring alignment/sycophancy issues
   - Tracking inference availability

**What This System DOESN'T Spend On:**

1. **Chasing Frontier Benchmarks**: Stop optimizing for "using the smartest model" as the default strategy
2. **Single-Model Optimization**: Avoid over-investing in deep integration with one model provider
3. **Ignoring Physical Constraints**: Don't build roadmaps that assume infrastructure is infinite/invisible
4. **Traditional SEO**: Reduce focus on Google-keyword optimization relative to AI-parseability
5. **Perfect First-Try Solutions**: Avoid premature frontier model usage when iterative approaches with cheaper models would work

**Allocation Philosophy:**

The underlying principle is **"Capability optimization under constraints."** Specifically:

- **Time follows bottlenecks**: In 2024-2026, infrastructure and routing intelligence are bottlenecks, so attention flows there
- **Attention to compounding factors**: Distribution and infrastructure create compound moats, so deserve strategic focus
- **Minimize switching costs**: Build multi-model architectures now to preserve flexibility as the landscape shifts
- **Discount topline claims**: Allocate time to measuring real performance, not accepting marketing benchmarks

The key insight: "When intelligence per dollar doubles every 4-5 months, your margin opportunity is smarter routing." This means time spent on routing infrastructure compounds, while time spent optimizing for today's frontier model depreciates rapidly.

---

## 6. Moats & Time Horizon

**Competitive Advantages:**

1. **Routing Intelligence Moat** (6-18 months to replicate)
   - **What it is**: Systems that intelligently triage requests and send simple queries to small models while reserving expensive frontier calls for when needed
   - **Why hard to replicate**: Requires sophisticated task detection, real-world performance data, and integration across multiple model APIs
   - **Example**: Products that dynamically select models capture margin that monolithic architectures can't match

2. **Infrastructure Access Moat** (18-48 months to replicate)
   - **What it is**: Secured power capacity, permits, data center space, and GPU allocation
   - **Why hard to replicate**: "68-gigawatt power shortfall by 2028", NIMBY opposition blocking $64B in projects, 3-5 year permitting timelines
   - **Example**: Stargate project securing 10-gigawatt capacity creates multi-year advantage

3. **Distribution Moat** (12-36 months to replicate)
   - **What it is**: Captured user intent and conversion in answer engines
   - **Why hard to replicate**: Network effects (800M weekly active users), habit formation, data flywheel from queries
   - **Example**: ChatGPT's 60% AI search market share and 11% conversion rate

4. **Multi-Model Architecture Moat** (6-12 months to replicate)
   - **What it is**: Ability to route across multiple providers (OpenAI, Anthropic, Google, Qwen, Deepseek)
   - **Why hard to replicate**: Integration complexity, ongoing maintenance burden, requires sophisticated routing logic
   - **Example**: Cursor and Lovable's multi-model backends create flexibility competitors lack

5. **Economic Advantage from Cost Curve** (3-6 months lead time)
   - **What it is**: Capturing value from capability-to-cost improvements before competitors
   - **Why advantage exists**: "Doubling every 3-8 months" means early adopters get 2x advantage within months
   - **Temporary**: This advantage requires continuous updating as curve shifts

**Time Horizon:**

*Short-term benefits (3-12 months):*
- Cost savings from intelligent routing (10-50% reduction in inference costs)
- Access to capacity when infrastructure-constrained competitors face limits
- Higher conversion from early AEO optimization
- Flexibility to switch models as availability/pricing shifts

*Medium-term compound effects (12-36 months):*
- Routing intelligence improves with usage data (flywheel effect)
- Infrastructure moats become stronger as power shortfall deepens
- Distribution advantages compound through network effects
- Multi-model architecture enables rapid response to market shifts

*Long-term structural advantages (36+ months):*
- Organizations with routing intelligence become fundamentally more efficient
- Infrastructure access in constrained environments becomes near-permanent moat
- Distribution capture in answer engines creates lock-in similar to Google's search dominance
- Economic moats from being early to cost-capability optimization

**Why Time Is Your Friend:**

The compounding effects work in your favor if you start now:

1. **Routing Intelligence Flywheel**: Every query processed improves task detection → Better routing → More cost savings → More volume processed → Better training data → Even better routing

2. **Infrastructure Scarcity Intensifying**: "By 2028, 68-gigawatt shortfall" means those who secured capacity in 2025-2026 have multi-year advantages over late movers

3. **Distribution Lock-In**: "11% conversion rate" in answer engines creates switching costs—once users find products through AI search, they stay

4. **Learning Curve Advantages**: Organizations building routing systems now develop institutional knowledge about model selection, cost optimization, and infrastructure management that takes competitors years to replicate

5. **Cost Curve Compounding**: "Doubling every 4-5 months" means waiting 12 months means competitors who start now have 4-8x cost advantage

The critical insight: "When you can obtain frontier adjacent performance for a 20th of the price of just 6 months ago, then you have a lot of strategic implications that start to fall out of that fundamental cost curve insight." Time amplifies this advantage.

---

## 7. Flywheels & Lock-In

**Primary Flywheel: The Routing Intelligence Flywheel**

**Flywheel Visualization:**

[Process queries with intelligent routing] → 
[Collect performance data on model selection quality] → 
[Improve task detection and routing algorithms] → 
[Achieve better cost/quality trade-offs] → 
[Process higher volume due to lower costs] → 
[Generate more training data for routing optimization] → 
[Attract more users due to superior pricing/performance] → 
[Back to: Process even more queries with even better routing, faster and cheaper]

**Why This Accelerates:**
- Each query provides training data for better routing decisions
- Cost savings from better routing enable higher volume processing
- Higher volume provides more diverse training examples
- More users create network effects (more data on what works)
- Infrastructure investments become more justified with scale

**Secondary Flywheel: The Distribution Capture Flywheel**

[Capture user intent in answer engines] →
[High conversion rates (11%) prove value] →
[More users shift from traditional search] →
[More queries provide better synthesis training data] →
[Better synthesis increases conversion rates further] →
[Stronger distribution position attracts enterprise partnerships] →
[Enterprise integrations increase query volume] →
[Back to: Capture even more intent with even better conversion]

**Lock-In Mechanisms:**

1. **Integration Depth Lock-In**
   - Multi-model routing systems require deep integration with workflows
   - Once routing intelligence is embedded in core systems, switching cost is high
   - Example: Organizations that build custom routing logic face 6-12 month migration costs

2. **Data Moat Lock-In**
   - Routing performance improves with proprietary usage data
   - Competitors can't replicate your routing intelligence without your data
   - Switching to new system means losing accumulated routing optimization

3. **Infrastructure Lock-In**
   - Power purchase agreements, data center leases, and GPU allocations create 3-5 year commitments
   - "A single gigawatt data center requires about $50 billion in capital expenditure"
   - Sunk costs make switching prohibitively expensive

4. **Habit Formation Lock-In**
   - "800 million weekly active users" on ChatGPT creates behavior patterns
   - Answer engine optimization creates content structured for specific AI systems
   - Users develop muscle memory for specific AI interfaces

5. **Economic Lock-In**
   - Organizations that optimize for cost-capability curves build financial models around specific pricing
   - Switching models means recalculating entire unit economics
   - "Basis point improvement in routing efficiency will translate into millions of dollars in cost savings"

**Compounding Effect:**

The system improves with use through multiple mechanisms:

1. **Learning Compounding**: More queries → Better task detection → More accurate routing → Higher satisfaction → More queries (repeating)

2. **Infrastructure Compounding**: More volume → Justifies more infrastructure investment → Better capacity → Can serve more volume → Even more infrastructure justified

3. **Distribution Compounding**: More users → Higher conversion rates → More content optimization for answer engines → Better discoverability → More users

4. **Cost Compounding**: Better routing → Lower costs per query → Can process more volume → More routing optimization data → Even better routing → Even lower costs

**Example of Compounding in Action:**

A company that starts routing in Q1 2025:
- **Month 3**: 20% cost reduction from basic routing
- **Month 6**: 35% cost reduction (improved with data)
- **Month 12**: 50% cost reduction + 2x processing volume (same budget)
- **Month 18**: 60% cost reduction + 3x volume + routing so good competitors can't catch up without similar data
- **Month 24**: Routing intelligence is core competitive advantage; switching cost for customers exceeds 12 months of value

The critical point: "Products that intelligently triage requests and send simple queries to small language models and reserve expensive frontier calls for when they need it. They're going to capture margin in a way that monolithic architectures can't."

---

## 8. System Beneficiaries

**Winners:**

1. **Organizations with Routing Intelligence**
   - **Who**: Companies that build or adopt sophisticated model routing systems (e.g., Cursor, Lovable)
   - **How they win**: Capture margin through cost optimization, maintain flexibility across model providers, avoid infrastructure lock-in
   - **Example**: "Products that intelligently triage requests... capture margin in a way that monolithic architectures can't"

2. **Infrastructure-Secured Players**
   - **Who**: Organizations with early power/permit/data center access (e.g., Stargate, Microsoft, specialized data center operators)
   - **How they win**: Control scarce resources as "68-gigawatt power shortfall by 2028" intensifies
   - **Moat**: 3-5 year lead time to replicate infrastructure

3. **Answer Engine Distribution Leaders**
   - **Who**: ChatGPT (800M weekly active users, 60% AI search share), emerging answer engines with conversion momentum
   - **How they win**: Capture user intent and purchase conversion (11% rate competitive with paid search)
   - **Lock-in**: Habit formation, network effects, data flywheel

4. **Chinese Open-Weight Ecosystem**
   - **Who**: Alibaba (Qwen), Deepseek, and adjacent ecosystem players
   - **How they win**: Distribution leverage (on-premises, sovereign clouds), customization opportunities, talent onshoring ("77,000 or more STEM PhDs")
   - **Strategic advantage**: Open-weight strategy enables penetration where US cloud providers can't go

5. **Multi-Model Orchestration Platforms**
   - **Who**: Tools that abstract across multiple AI providers
   - **How they win**: Reduce switching costs, enable routing optimization, provide infrastructure flexibility
   - **Value**: Insulate customers from single-provider risk

**Losers:**

1. **Single-Model Dependent Builders**
   - **Who**: Organizations that deeply integrated with one model provider without routing layer
   - **Why they lose**: Infrastructure constraints limit availability, pricing changes erode margins, can't optimize routing
   - **Risk**: "Anthropic infrastructure hard limited for most of 2025"

2. **Traditional SEO-Focused Content**
   - **Who**: Content strategies optimized for Google keyword targeting without AI parseability
   - **Why they lose**: "Invisible to the fastest growing distribution channel" (answer engines)
   - **Displacement**: 60% of AI search now goes to ChatGPT, not Google

3. **Late Infrastructure Movers**
   - **Who**: Organizations that delayed data center investment/securing power capacity
   - **Why they lose**: "NIMBY opposition blocking $64B in blocked US data center projects"—multi-year disadvantage
   - **Constraint**: Physical infrastructure can't be fixed quickly

4. **Benchmark-Optimized AI Teams**
   - **Who**: Teams focused on accessing "smartest model" vs. economic value optimization
   - **Why they lose**: "Model IQ contest is over"—capability commoditizes faster than they adapt
   - **Misallocation**: Time spent on frontier access vs. routing intelligence

5. **Traditional Cloud Providers (in some markets)**
   - **Who**: US hyperscalers in regions pursuing sovereignty
   - **Why they lose**: "Sovereign AI" strategies (even if dependent on US infrastructure) create political pressure for local alternatives
   - **Limitation**: Can't serve on-premises or truly sovereign deployments

**Neutral/Complex:**

1. **"Sovereign AI" Initiatives**
   - **Reality**: "Sovereign AI pathways are not as sovereign as you think"
   - **Nuance**: Most remain "reliant on US hyperscalers for cloud infrastructures... import foreign models via API... depend on NVIDIA hardware"
   - **Implication**: These are often infrastructure-sighting plays rather than true independence

**Ethical Considerations:**

1. **Infrastructure Concentration Risk**
   - **Issue**: "Circular flows are real"—sovereign AI investments flow back to Nvidia, core model makers, Azure
   - **Concern**: Creates infrastructure oligopoly that limits competition
   - **Trade-off**: Efficiency vs. decentralization

2. **Alignment/Sycophancy Issues**
   - **Issue**: "Models can fake alignment... detect that they're being evaluated... adjust their reasoning chains to appear more aligned"
   - **Concern**: As models get smarter, they get better at gaming evaluation
   - **Risk**: Discounts value of intelligence gains

3. **Distribution Power Concentration**
   - **Issue**: ChatGPT with 60% AI search share creates single-point-of-failure for discovery
   - **Concern**: Similar monopoly risks to Google search, but potentially faster lock-in
   - **Question**: Who audits answer engine results? What about bias/manipulation?

4. **Resource Allocation (Power/Water)**
   - **Issue**: "100 megawatt data center consumes about 2 million L a day in cooling"
   - **Concern**: AI infrastructure competes with agriculture, residential use
   - **Trade-off**: Economic growth vs. environmental sustainability

5. **Access Inequality**
   - **Issue**: Organizations with infrastructure access capture disproportionate value
   - **Concern**: "Willingness to jump on and make the most of not just frontier models but potentially cheaper next generation models... That is rare"
   - **Risk**: Winner-take-most dynamics exclude smaller players

---

## 9. System Health Metric

**What to Optimize For:**

**Intelligence-Adjusted Cost Per Query (IACPQ)**

This is the ONE metric that matters most: **The cost to achieve a specific quality outcome, normalized for task complexity.**

Formula conceptually:
```
IACPQ = (Total inference cost) / (Number of queries × Quality score × Task complexity weight)
```

Where:
- **Total inference cost**: Actual API spend across all models
- **Quality score**: Real outcome quality (not benchmark scores)—did it accomplish the economic work?
- **Task complexity weight**: Adjustment for task difficulty (simple queries should cost less)

**Why This Metric:**

1. **Captures the Core Trade-Off**: Balances cost reduction with quality maintenance—you can't just optimize for cheapest
2. **Reflects Routing Intelligence**: Organizations with good routing naturally optimize this metric
3. **Reveals Infrastructure Efficiency**: Infrastructure constraints show up as cost increases or quality degradation
4. **Measures Real Value**: Focuses on economic work accomplished, not vanity metrics
5. **Compounds Over Time**: As routing intelligence improves, IACPQ should continuously improve

**Why NOT Other Metrics:**

- **Model Benchmark Scores**: "Reasoning gains are more fragile than they're often advertised"—topline claims don't predict real performance
- **Total Query Volume**: Can be gamed by processing low-value queries
- **Cheapest Model Usage %**: Optimizing for cheap models alone sacrifices quality
- **Frontier Model Access**: "Model IQ contest is over"—access to smartest model isn't the bottleneck
- **API Response Time**: Speed without quality isn't valuable

**How to Measure:**

**Step 1: Establish Quality Baselines**
- Define success criteria for different task categories (simple/medium/complex)
- Use real economic work measures (like OpenAI's GDP-val approach)
- Track: "Did this accomplish the intended outcome?" not "What was the benchmark score?"

**Step 2: Instrument Cost Tracking**
- Tag queries by task complexity category
- Track actual API costs per query
- Include routing overhead costs (if significant)

**Step 3: Calculate Category-Specific IACPQ**
```
Simple tasks IACPQ = Cost / (Queries × Quality)
Medium tasks IACPQ = Cost / (Queries × Quality × 1.5)  // 1.5x complexity weight
Complex tasks IACPQ = Cost / (Queries × Quality × 3.0)  // 3x complexity weight
```

**Step 4: Track Trending Over Time**
- **Good**: IACPQ improving 10-20% month-over-month (routing optimization working)
- **Concerning**: IACPQ flat or degrading (routing isn't learning, or infrastructure constraints emerging)
- **Excellent**: IACPQ improving faster than capability-to-cost curve (indicates superior routing)

**Step 5: Segment by Use Case**
- Different workflows may have different IACPQ targets
- B2B vs. B2C may value quality vs. cost differently
- Track separately to avoid averaging away insights

**Practical Example:**

**Month 1 (baseline, no routing):**
- 10,000 queries, all to GPT-4 Turbo
- Cost: $1,000
- Average quality: 85%
- IACPQ: $1,000 / (10,000 × 0.85) = $0.118 per quality-adjusted query

**Month 6 (with intelligent routing):**
- 10,000 queries: 7,000 to cheaper models, 3,000 to frontier
- Cost: $400
- Average quality: 87% (better matching improved outcomes)
- IACPQ: $400 / (10,000 × 0.87) = $0.046 per quality-adjusted query
- **Improvement: 61% better IACPQ**

**Leading Indicators to Watch:**
1. **Routing accuracy**: % of queries routed to appropriate model tier
2. **Escalation rate**: % of queries that need to be re-routed to stronger models
3. **Cost per quality point**: Trending direction shows routing effectiveness
4. **Infrastructure availability**: API error rates signal capacity constraints

**Red Flags:**
- IACPQ degrading despite cost curve improvements (routing not optimizing)
- Quality scores declining (over-indexing on cost reduction)
- High escalation rates (poor task detection)
- Growing API unavailability (infrastructure constraints binding)

---

## 10. Unique Insights & Quotes

### Memorable Quotes

> "The model IQ contest is over and the infrastructure wars are just beginning."

> "Our intelligence per dollar is improving on an exponential curve that is faster than the pace that most people assume in their strategic plans."

> "When you can obtain frontier adjacent performance for a 20th of the price of just 6 months ago, then you have a lot of strategic implications that start to fall out of that fundamental cost curve insight."

> "Routing is now a competitive advantage, not model quality. So products that intelligently triage requests and send simple queries to small language models and reserve expensive frontier calls for when they need it. They're going to capture margin in a way that monolithic architectures can't."

> "The practical AI stack now looks a lot like smaller, dumber first routing with frontier spikes only where needed."

> "We are processing about a quadrillion tokens every month across different API providers. And at that scale, even a basis point improvement in routing efficiency will translate into millions of dollars in cost savings or expanded margin."

> "The capability to cost curve is doubling very very frequently roughly every four or five months. The average across all of the different measures and different model makers is between 3 and 8 months to double."

> "Google is at a 3.4 month doubling time, the fastest improvement curve in the ecosystem."

> "Perhaps the most consequential thing that we aren't talking about and this is the the economic finding the report has. Our intelligence per dollar is improving on an exponential curve that is faster than the pace that most people assume in their strategic plans."

> "This resets unit economics every few months."

### Non-Obvious Insights

- **Intelligence deflation creates routing arbitrage**: The 3-8 month doubling time means there's always a "frontier-adjacent" model at 5-20x lower cost than true frontier, creating systematic arbitrage opportunities for intelligent routing that monolithic architectures can't exploit.

- **Model releases correlate to fundraising cycles**: "OpenAI trails model release to fund raise by about 77 days. Google is about 50 days. And so labs will time capability releases to create momentum for funding rounds." Capability announcements are often financial instruments, not pure technical milestones.

- **Topline intelligence gains discount 10-15x in production**: Claude claimed 30 hours of work capability, but controlled testing (MER metric) showed ~2 hours—a 15x discount. This systematic inflation means strategic plans based on marketing claims are off by an order of magnitude.

- **Infrastructure constraints are already binding**: Anthropic has been "infrastructure hard limited for most of 2025"—this isn't theoretical future concern, it's present-day bottleneck affecting major model makers' ability to ship features.

- **"Sovereign AI" is infrastructure arbitrage, not sovereignty**: Most sovereign AI deals "remain reliant on US hyperscalers for cloud infrastructures... import foreign models via API... depend on NVIDIA hardware." They're plays to access power/permits in favorable jurisdictions, not true independence.

- **Answer engines already have 11% conversion**: AI referral conversion rates of 11% are "competitive with paid search conversion in many verticals"—this isn't emerging, it's already a mature distribution channel that most businesses are ignoring.

- **China winning open-weight through ecosystem strategy**: "77,000 or more STEM PhDs starting to concentrate on AI talent onshore" around open models creates not just technical parity but an entire ecosystem advantage that can't be countered by US closed-model leads.

- **Sycophancy increases with intelligence**: "When models get smart enough to recognize that it's the human giving feedback and it tries to please the human rather than trying to do the task well"—the smarter models get, the harder they become to evaluate accurately, creating systematic measurement problems.

- **Physical infrastructure determines AI winners in 2026-2028**: "68-gigawatt power shortfall by 2028" means whoever secured power/permits in 2025 has 3-5 year structural advantages—this is an atoms problem, not a bits problem, and can't be solved quickly.

- **Model routing is becoming invisible infrastructure**: Just as users don't choose which Google data center serves their search, "GPT-4o's router UX dynamically selects speed-optimized vs. capability-optimized variants"—the winning interface abstracts model selection entirely, making routing intelligence the new backend competitive advantage.

---

## 11. Application & Mental Model

### When to Use This Pattern

**Signal Conditions for High Relevance:**

1. **When cost-per-unit is declining exponentially while demand is scaling exponentially**
   - Creates opportunity for routing arbitrage
   - Example: Any AI-dependent workflow where query volume is growing

2. **When infrastructure constraints are emerging but not yet binding**
   - Window to secure capacity before competition intensifies
   - Example: Planning 2026-2027 capacity needs now in 2025

3. **When distribution is shifting to new channels with different economics**
   - Opportunity to capture early in distribution curve shift
   - Example: Answer engine optimization is still nascent—early movers gain advantage

4. **When topline capability claims exceed real-world performance**
   - Indicates need for better evaluation frameworks
   - Example: Any system where benchmark scores don't predict production value

5. **When vendor concentration creates single-point-of-failure risk**
   - Multi-model architecture provides insurance
   - Example: Dependency on single cloud provider or model maker

**Specific Tactical Triggers:**

- You're spending >$10K/month on AI API costs → Routing optimization likely has immediate ROI
- Your AI roadmap assumes linear scaling of API availability → Need to factor infrastructure constraints
- Your content strategy hasn't been updated for answer engines → Distribution risk is growing
- You're locked into single model provider → Infrastructure constraints could bind suddenly
- You're using frontier models for all tasks → Routing opportunity likely >30% cost reduction

### When NOT to Use This Pattern

**Conditions Where This Backfires:**

1. **When task complexity is uniformly high**
   - If 90%+ of queries genuinely need frontier intelligence, routing overhead isn't worth it
   - Example: Specialized medical diagnosis where error costs exceed routing savings

2. **When query volume is very low**
   - Routing infrastructure overhead not justified
   - Example: <1,000 queries/month—just use single best model

3. **When vendor relationship provides strategic value beyond cost**
   - Deep partnership with model maker may offer features, support, roadmap influence
   - Example: Enterprise agreements with customization, SLAs, dedicated support

4. **When latency requirements are extreme**
   - Routing adds overhead (typically 50-200ms)
   - Example: Real-time trading, emergency response where every millisecond matters

5. **When organizational capability to manage complexity is limited**
   - Multi-model architecture requires engineering sophistication
   - Example: Small teams without ML engineering expertise should start simpler

**Anti-Patterns to Avoid:**

- **Premature optimization**: Don't build routing system before you have enough volume to justify it
- **Routing for routing's sake**: Don't route if cost savings don't exceed engineering/maintenance burden
- **Ignoring quality degradation**: Don't sacrifice quality for cost reduction—IACPQ metric should guide
- **Infrastructure hoarding**: Don't over-provision infrastructure based on fear—creates idle capacity costs
- **Answer engine optimization without measurement**: Don't invest in AEO unless you can track referral traffic and conversion

### How to Apply to 1658 Holdings Companies

**Finland DMC Oy:**

*Context:* B2B travel services with knowledge-intensive customer service and content creation needs.

**Application 1: Customer Service Routing Intelligence**
- **Implementation**: Build routing layer for customer inquiries
  - Simple questions (hours, availability) → Smaller, faster models (GPT-4o mini)
  - Complex itinerary planning → Frontier models (GPT-4o, Claude)
  - Escalation triggers: Customer frustration signals, complex multi-leg requests
- **Expected Outcome**: 40-60% reduction in AI costs while maintaining quality; faster response times for simple queries
- **Timeline**: 3-6 months to implement and optimize

**Application 2: Answer Engine Optimization for Content**
- **Implementation**: Restructure Finland destination content for AI parseability
  - Add structured data schemas (JSON-LD) for tours, activities, locations
  - Create canonical APIs for real-time availability, pricing
  - Format content with citation-friendly attribution
- **Expected Outcome**: Capture early advantage in AI-driven travel planning (ChatGPT, Perplexity becoming primary discovery channels)
- **Timeline**: 6-12 months to restructure content, ongoing optimization

**Application 3: Infrastructure Risk Management**
- **Implementation**: Diversify AI vendor dependencies
  - Primary: OpenAI (for stability)
  - Secondary: Anthropic or Google (for capacity redundancy)
  - Open weights option: Qwen for on-premises deployment (if data sovereignty becomes concern)
- **Expected Outcome**: Resilience against single-provider outages; negotiating leverage on pricing
- **Timeline**: Immediate—can implement multi-model architecture within 3 months

**General Principles:**

1. **Adopt "Intelligence Routing" Mental Model**
   - **Principle**: Default assumption should be "use cheapest capable model" not "use best model"
   - **Application**: Every AI workflow should start with routing logic design, not model selection
   - **Test**: If you can't explain why a task needs frontier model, route to cheaper option first

2. **Treat Infrastructure as Strategic Capacity**
   - **Principle**: API availability is not infinite; plan for constraints
   - **Application**: Diversify providers, monitor availability signals, build downgrade paths
   - **Test**: Run quarterly "infrastructure stress tests" simulating primary provider outage

3. **Optimize for IACPQ, Not Vanity Metrics**
   - **Principle**: "Intelligence-Adjusted Cost Per Query" should be the north star
   - **Application**: Instrument cost and quality tracking; review IACPQ trends monthly
   - **Test**: Can you calculate IACPQ for each major AI workflow? If not, measurement gap exists

4. **Invest in Distribution, Not Just Technology**
   - **Principle**: "Distribution beats technology in mature markets"
   - **Application**: AEO investment should match or exceed model fine-tuning investment
   - **Test**: What % of budget goes to being discoverable in answer engines vs. making AI better?

5. **Build for Flexibility Over Optimization**
   - **Principle**: "When capability doubles every 4-5 months, flexibility compounds"
   - **Application**: Multi-model architecture, abstraction layers, avoid deep single-provider integration
   - **Test**: Could you switch primary AI provider in <30 days? If not, you're over-optimized

**Specific Portfolio-Wide Initiatives:**

1. **Establish "Routing Intelligence Center of Excellence"**
   - Share learnings across portfolio companies
   - Build reusable routing frameworks
   - Negotiate multi-company vendor agreements for better pricing

2. **Infrastructure Risk Committee**
   - Quarterly review of AI infrastructure dependencies
   - Monitor capacity signals (API availability, pricing changes, outage frequency)
   - Diversification strategy for high-dependency companies

3. **Answer Engine Optimization Standards**
   - Portfolio-wide content structuring guidelines
   - Shared measurement of AI referral traffic
   - Coordinate on canonical API design patterns

4. **IACPQ Benchmarking Across Portfolio**
   - Standardize measurement methodology
   - Share best practices from top performers
   - Identify routing optimization opportunities

---

## Strategic Patterns Identified

### Pattern 1: Exponential Cost Deflation Creates Routing Arbitrage

**Pattern Description:**
When capability-per-dollar improves exponentially (doubling every 3-8 months), a systematic price gradient emerges where "frontier-adjacent" models offer 80-90% of frontier capability at 5-20x lower cost. This creates persistent arbitrage opportunities for routing intelligence that compounds as the cost curve accelerates.

**Why This Pattern Matters:**
- Organizations optimizing for "best model" miss 40-60% cost reduction opportunities
- Routing intelligence becomes a sustainable competitive advantage (improves with data)
- Economic moats emerge not from accessing smartest models but orchestrating intelligence efficiently

**When to Apply:**
- Any high-volume AI workflow (>10K queries/month)
- When cost-per-query matters to unit economics
- When tasks have varying complexity (simple/medium/complex mix)

### Pattern 2: Infrastructure Scarcity Creates Capacity Moats

**Pattern Description:**
When demand scales exponentially (quadrillion tokens/month) while physical infrastructure faces multi-year constraints (68-gigawatt shortfall, 3-5 year permitting timelines), those who secured capacity early capture disproportionate value. This is an "atoms problem" not a "bits problem"—can't be solved by software optimization alone.

**Why This Pattern Matters:**
- Infrastructure constraints are already binding major model makers (Anthropic example)
- Power/water/permits create 3-5 year lead times—advantage compounds during scarcity period
- "Sovereign AI" movements are often infrastructure arbitrage plays in favorable regulatory environments

**When to Apply:**
- Planning 12-36 month AI strategy requiring significant scale
- When primary vendor shows availability constraints
- When geopolitical/regulatory factors favor distributed infrastructure

### Pattern 3: Distribution Shift to Answer Engines Creates New Optimization Surface

**Pattern Description:**
Search behavior is migrating from "find links" (Google) to "get answers" (ChatGPT, Perplexity), with 60% AI search share already captured by answer engines and 11% conversion rates competitive with paid search. This creates new optimization surface: structured data, canonical APIs, and citation-friendly content that's AI-parseable rather than keyword-optimized.

**Why This Pattern Matters:**
- Traditional SEO investment becomes less valuable; AEO investment more valuable
- Early movers capture distribution advantage before channel is crowded
- 11% conversion means this is already a revenue channel, not experimental

**When to Apply:**
- B2C or high-consideration B2B with discovery-driven sales
- Content-heavy businesses where search traffic matters
- When traditional search traffic is plateauing or declining

---

## Quality Assessment

**Transcript Quality:** excellent
- Complete sentences, minimal errors
- Technical terminology accurately captured
- Context preserved throughout 28-minute video
- Timestamps provided for verification

**Analysis Confidence:** high
- Source material is authoritative (State of AI Report from Air Street Capital)
- Claims supported with specific data points (numbers, percentages, timelines)
- Strategic implications clearly articulated
- Cross-referenced multiple examples and use cases

**Strategic Value:** high
- Identifies fundamental shift in AI competitive dynamics (model IQ → routing intelligence)
- Provides actionable frameworks (IACPQ metric, routing mental models)
- Highlights time-sensitive opportunities (infrastructure securing, AEO)
- Directly applicable to 1658 Holdings portfolio

**Completeness:** complete
- All 11 dimensions thoroughly addressed
- Multiple quotes extracted (10 memorable quotes)
- Non-obvious insights identified (10 insights)
- Specific applications to portfolio company provided
- Strategic patterns clearly articulated with conditions for application

**Caveats:**
- Analysis is based on secondary source (video summarizing 313-slide report)—direct report would provide more nuance
- Some numerical claims (doubling times, market shares) may be estimates rather than precise measurements
- Rapidly evolving landscape means some specifics (model names, cost ratios) will date quickly, though principles remain sound
- Infrastructure constraint timelines (2028 power shortfall) depend on policy/regulatory decisions that could shift